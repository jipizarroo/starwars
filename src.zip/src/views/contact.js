import React from 'react';
import { Context } from './../store/appContext';


const Contact = () => {
    return (
        <Context.Consumer>
            {
                (context) => {

                    return (
                        <div className="container">
                            <div className="row">
                                <div className="col">
                                    <ul>
                                        {
                                            !!context.store.planets.results &&
                                            context.store.planets.results.map((item, i) => {
                                                return <li key={i}>{item.name} </li>
                                            })

                                        }
                                    </ul>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col d-flex justify-content-between">
                                    <button className="btn btn-info" onClick={() => context.actions.getPlanets(context.store.planets.previous)}>
                                        Previous
                                    </button>
                                    <button className="btn btn-info" onClick={() => context.actions.getPlanets(context.store.planets.Next)}>
                                        Next
                                    </button>
                                </div>
                            </div>
                        </div>

                    )
                }
            }
        </Context.Consumer>
    )
}

export default Contact; 