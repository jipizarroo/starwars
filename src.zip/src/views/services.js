import React from 'react';


const Services = () =>{
    return(
        <h1>SERVICES</h1>
    )
}

export default Services;